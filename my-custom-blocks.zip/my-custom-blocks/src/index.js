const { registerBlockType } = wp.blocks;

registerBlockType( 'izhar/custom-block', {
	title: 'My Custom Block',
	description: 'Block create a custom field to add meta data.',
	icon: 'admin-comments',
	category: 'common',
	attributes: {
		content: {
			type: 'string'
		}
	},
	edit({ attributes, setAttributes }) {
		
		//Custom Function
		function updateContent(event) {
			setAttributes({ content: event.target.value});
		}
		
		return <input class="one_com_meta_field" value={ attributes.content } onChange={ updateContent } type="text" />;
	},
	save({ attributes }) {
		return <p>{ attributes.content }</p>; 
	} 
});